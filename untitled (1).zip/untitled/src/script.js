const colors = [
  "red", "blue", "green", "yellow", "purple", "orange", "pink", "brown",
  "black", "white", "gray", "cyan", "magenta", "lime", "teal", "maroon",
  "olive", "navy", "gold", "silver", "beige", "coral", "indigo", "violet",
  "tan", "salmon", "khaki", "peach", "plum", "mint", "aqua", "lavender",
  "chocolate", "crimson", "azure", "turquoise", "amber", "emerald",
  "ivory", "ruby", "sapphire", "jade", "rose", "charcoal", "periwinkle",
  "fuchsia", "orchid", "mahogany", "sepia", "apricot", "copper", "bronze",
  "pearl", "chartreuse", "aquamarine", "scarlet", "raspberry", "moss"
];

let targetCake = [];
let playerCake = [];

// Crear botones para los colores
function createColorButtons() {
  const buttonsContainer = document.getElementById("buttons-container");
  buttonsContainer.innerHTML = ""; // Limpiar antes de añadir los botones

  colors.forEach(color => {
    const button = document.createElement("button");
    button.className = "color-button";
    button.style.backgroundColor = color;
    button.onclick = () => addLayer(color);
    buttonsContainer.appendChild(button);
  });
}

// Generar el pastel objetivo
function generateTargetCake() {
  const newLayerCount = targetCake.length + 1; // Incrementa el número de capas
  targetCake = []; // Reinicia el pastel objetivo

  for (let i = 0; i < newLayerCount; i++) {
    const randomColor = colors[Math.floor(Math.random() * colors.length)];
    targetCake.push(randomColor);
  }

  updateCakeDisplay("target-cake-display", targetCake);
}

// Actualizar un pastel en la pantalla (objetivo o jugador)
function updateCakeDisplay(elementId, cake) {
  const display = document.getElementById(elementId);
  display.innerHTML = ""; // Limpia el contenido previo

  cake.forEach(color => {
    const layer = document.createElement("div");
    layer.className = `layer ${color}`;
    layer.style.backgroundColor = color; // Estilo dinámico
    display.appendChild(layer);
  });
}

// Agregar una capa al pastel del jugador
function addLayer(color) {
  playerCake.push(color);
  updateCakeDisplay("player-cake", playerCake);
}

// Verificar si el pastel es correcto
function checkCake() {
  const resultDiv = document.getElementById("result");

  if (JSON.stringify(playerCake) === JSON.stringify(targetCake)) {
    resultDiv.textContent = "¡Correcto! 🎉 El pastel es perfecto.";
    resetGame(true); // Reiniciar y generar un nuevo pastel
  } else {
    resultDiv.textContent = "❌ Pastel incorrecto. ¡Intenta de nuevo!";
    resetGame(false); // Solo reiniciar el pastel del jugador
  }
}

// Reiniciar el juego o el pastel del jugador
function resetGame(addNewLayer) {
  playerCake = []; // Vaciar el pastel del jugador
  updateCakeDisplay("player-cake", playerCake);

  if (addNewLayer) {
    generateTargetCake(); // Generar un nuevo pastel objetivo
  }
}

// Inicializar el juego
createColorButtons();
generateTargetCake();
